package com.research.rcsmessagehook;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.provider.Settings;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Random;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/**
 * SIM卡配置类
 */
class SIMConfig {
    public String mcc;
    public String mnc;
    public String imsi;
    public String msisdn;
    public String iccid;
    public String operatorName;
    public String deviceId;
    public String androidId;
    public String countryIso;
    
    public SIMConfig(String mcc, String mnc, String imsi, String msisdn, 
                    String iccid, String operatorName, String deviceId, 
                    String androidId, String countryIso) {
        this.mcc = mcc;
        this.mnc = mnc;
        this.imsi = imsi;
        this.msisdn = msisdn;
        this.iccid = iccid;
        this.operatorName = operatorName;
        this.deviceId = deviceId;
        this.androidId = androidId;
        this.countryIso = countryIso;
    }
    
    public String getMccMnc() {
        return mcc + mnc;
    }
    
    @Override
    public String toString() {
        return "SIMConfig{" +
            "mcc='" + mcc + '\'' +
            ", mnc='" + mnc + '\'' +
            ", operatorName='" + operatorName + '\'' +
            ", countryIso='" + countryIso + '\'' +
            '}';
    }
}

/**
 * 📱 RCS消息Hook模块 - SIM伪装版本
 * 
 * 功能：
 * - 拦截RCS消息发送和接收
 * - 伪装SIM卡信息(IMSI、手机号、运营商等)
 * - 捕获Token和认证信息
 * - 监控RCS连接状态
 * - 详细日志记录
 * 
 * 使用方法：
 * 1. 编译为LSPosed模块
 * 2. 在LSPosed中启用并选择Google Messages
 * 3. 重启Google Messages应用
 * 4. 查看日志输出
 * 
 * @author RCS研究团队
 * @version 2.0 - SIM伪装版本
 */
public class RCSMessageHookModule implements IXposedHookLoadPackage {
    
    private static final String TAG = "RCSMessageHook";
    private static final String TARGET_PACKAGE = "com.google.android.apps.messaging";
    private static final String PREFS_NAME = "rcs_hook_prefs";
    
    // 捕获的数据存储
    private static final ConcurrentHashMap<String, Object> capturedTokens = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, Object> capturedParams = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, Object> capturedMessages = new ConcurrentHashMap<>();
    
    // 配置选项
    private static boolean enableDetailedLogging = true;
    private static boolean enableParameterModification = false;
    private static String customMessageContent = null;
    
    // SIM伪装配置
    private static boolean enableSIMSpoofing = true;
    private static SIMConfig fakeSIMConfig = null;
    private static final Map<String, SIMConfig> PREDEFINED_CONFIGS = new HashMap<>();
    private static final Random random = new Random();
    
    // 时间格式化器
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault());
    
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!TARGET_PACKAGE.equals(lpparam.packageName)) {
            return;
        }
        
        XposedBridge.log(TAG + " ✅ 开始Hook Google Messages RCS功能 (SIM伪装版本)");
        
        // 等待应用初始化完成
        XposedHelpers.findAndHookMethod(Application.class, "onCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                initializeHooks(lpparam);
            }
        });
    }
    
    /**
     * 初始化所有Hook
     */
    private void initializeHooks(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // 0. 初始化SIM伪装配置
            initializeSIMConfigs();
            
            // 1. Hook Firebase消息服务
            hookFirebaseMessaging(lpparam);
            
            // 2. Hook RCS消息发送
            hookRCSMessageSending(lpparam);
            
            // 3. Hook Token相关方法
            hookTokenMethods(lpparam);
            
            // 4. Hook SIM卡相关信息(伪装模式)
            hookSIMCardInfo(lpparam);
            
            // 5. Hook通用方法
            hookGenericMethods(lpparam);
            
            XposedBridge.log(TAG + " ✅ 所有Hook初始化完成 (SIM伪装模式)");
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ❌ Hook初始化失败: " + e.getMessage());
        }
    }
    
    /**
     * Hook Firebase消息服务
     */
    private void hookFirebaseMessaging(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // Hook Firebase消息接收
            Class<?> firebaseClass = XposedHelpers.findClass(
                "com.google.firebase.messaging.FirebaseMessagingService", 
                lpparam.classLoader
            );
            
            XposedHelpers.findAndHookMethod(firebaseClass, "onMessageReceived", 
                RemoteMessage.class, new XC_MethodHook() {
                @Override
                protected void beforeHookMethod(MethodHookParam param) throws Throwable {
                    RemoteMessage message = (RemoteMessage) param.args[0];
                    logMessage("Firebase消息接收", message);
                    
                    // 捕获消息数据
                    Map<String, String> data = message.getData();
                    if (data != null && !data.isEmpty()) {
                        capturedMessages.put("firebase_" + System.currentTimeMillis(), data);
                        logInfo("📋 消息数据: " + data.toString());
                    }
                }
            });
            
            // Hook Firebase Token获取
            XposedHelpers.findAndHookMethod(firebaseClass, "onNewToken", 
                String.class, new XC_MethodHook() {
                @Override
                protected void beforeHookMethod(MethodHookParam param) throws Throwable {
                    String token = (String) param.args[0];
                    logInfo("🔑 Firebase Token: " + token);
                    capturedTokens.put("firebase_token", token);
                    capturedTokens.put("firebase_token_time", getCurrentTimestamp());
                }
            });
            
            XposedBridge.log(TAG + " ✅ Firebase Hook设置完成");
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ⚠️ Firebase Hook设置失败: " + e.getMessage());
        }
    }
    
    /**
     * Hook RCS消息发送
     */
    private void hookRCSMessageSending(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // Hook所有包含"send"的方法
            hookMethodsByName("send", "消息发送", lpparam);
            hookMethodsByName("Send", "消息发送", lpparam);
            
            // Hook消息构建相关方法
            hookMethodsByName("build", "消息构建", lpparam);
            hookMethodsByName("create", "消息创建", lpparam);
            
            XposedBridge.log(TAG + " ✅ RCS消息发送Hook设置完成");
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ⚠️ RCS消息发送Hook设置失败: " + e.getMessage());
        }
    }
    
    /**
     * Hook Token相关方法
     */
    private void hookTokenMethods(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // Hook所有包含"token"的方法
            hookMethodsByName("token", "Token处理", lpparam);
            hookMethodsByName("Token", "Token处理", lpparam);
            
            // Hook认证相关方法
            hookMethodsByName("auth", "认证", lpparam);
            hookMethodsByName("Auth", "认证", lpparam);
            
            // Hook Jibe相关方法
            hookMethodsByName("jibe", "Jibe服务", lpparam);
            hookMethodsByName("Jibe", "Jibe服务", lpparam);
            
            XposedBridge.log(TAG + " ✅ Token Hook设置完成");
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ⚠️ Token Hook设置失败: " + e.getMessage());
        }
    }
    
    /**
     * Hook通用方法
     */
    private void hookGenericMethods(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // Hook RCS相关方法
            hookMethodsByName("rcs", "RCS功能", lpparam);
            hookMethodsByName("Rcs", "RCS功能", lpparam);
            hookMethodsByName("RCS", "RCS功能", lpparam);
            
            // Hook消息相关方法
            hookMethodsByName("message", "消息处理", lpparam);
            hookMethodsByName("Message", "消息处理", lpparam);
            
            // Hook连接相关方法
            hookMethodsByName("connect", "连接", lpparam);
            hookMethodsByName("Connect", "连接", lpparam);
            
            XposedBridge.log(TAG + " ✅ 通用Hook设置完成");
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ⚠️ 通用Hook设置失败: " + e.getMessage());
        }
    }
    
    /**
     * 根据方法名模式Hook方法
     */
    private void hookMethodsByName(String namePattern, String description, XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // 尝试Hook一些已知的类
            String[] knownClasses = {
                "com.google.android.apps.messaging.shared.datamodel.action.SendMessageAction",
                "com.google.android.apps.messaging.shared.datamodel.action.InsertNewMessageAction",
                "com.google.android.apps.messaging.shared.fcm.BugleFirebaseMessagingService",
                "com.google.android.apps.messaging.shared.rcs.RcsManager",
                "com.google.android.apps.messaging.shared.rcs.RcsMessageSender"
            };
            
            for (String className : knownClasses) {
                try {
                    Class<?> clazz = Class.forName(className);
                    hookMethodsInClass(clazz, namePattern, description, lpparam);
                } catch (ClassNotFoundException e) {
                    // 类不存在，跳过
                }
            }
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ⚠️ Hook方法 " + namePattern + " 失败: " + e.getMessage());
        }
    }
    
    /**
     * Hook类中包含指定名称模式的方法
     */
    private void hookMethodsInClass(Class<?> clazz, String namePattern, String description, XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Method[] methods = clazz.getDeclaredMethods();
            for (Method method : methods) {
                if (method.getName().toLowerCase().contains(namePattern.toLowerCase())) {
                    XposedBridge.hookMethod(method, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            logMethodCall(method, param, description, "调用前");
                        }
                        
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            logMethodCall(method, param, description, "调用后");
                            captureMethodResult(method, param);
                        }
                    });
                }
            }
        } catch (Exception e) {
            XposedBridge.log(TAG + " ⚠️ Hook类 " + clazz.getName() + " 失败: " + e.getMessage());
        }
    }
    
    /**
     * 记录方法调用
     */
    private void logMethodCall(Method method, XC_MethodHook.MethodHookParam param, String description, String phase) {
        if (!enableDetailedLogging) return;
        
        try {
            StringBuilder logMessage = new StringBuilder();
            logMessage.append("🔍 ").append(description).append(" - ").append(phase).append("\n");
            logMessage.append("   类: ").append(method.getDeclaringClass().getSimpleName()).append("\n");
            logMessage.append("   方法: ").append(method.getName()).append("\n");
            
            // 记录参数
            if (param.args != null && param.args.length > 0) {
                logMessage.append("   参数: ");
                for (int i = 0; i < param.args.length; i++) {
                    if (i > 0) logMessage.append(", ");
                    Object arg = param.args[i];
                    if (arg != null) {
                        logMessage.append(arg.getClass().getSimpleName()).append("=").append(arg.toString());
                    } else {
                        logMessage.append("null");
                    }
                }
                logMessage.append("\n");
            }
            
            // 记录返回值（仅在调用后）
            if ("调用后".equals(phase) && param.getResult() != null) {
                logMessage.append("   返回值: ").append(param.getResult().toString()).append("\n");
            }
            
            XposedBridge.log(TAG + " " + logMessage.toString());
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ❌ 记录方法调用失败: " + e.getMessage());
        }
    }
    
    /**
     * 捕获方法结果
     */
    private void captureMethodResult(Method method, XC_MethodHook.MethodHookParam param) {
        try {
            String methodKey = method.getDeclaringClass().getSimpleName() + "." + method.getName();
            
            // 捕获Token相关结果
            if (method.getName().toLowerCase().contains("token") || 
                method.getName().toLowerCase().contains("auth")) {
                Object result = param.getResult();
                if (result != null) {
                    capturedTokens.put(methodKey, result.toString());
                    capturedTokens.put(methodKey + "_time", getCurrentTimestamp());
                    logInfo("🔑 Token捕获: " + methodKey + " -> " + result.toString());
                }
            }
            
            // 捕获消息相关结果
            if (method.getName().toLowerCase().contains("message") ||
                method.getName().toLowerCase().contains("send")) {
                Object result = param.getResult();
                if (result != null) {
                    capturedMessages.put(methodKey + "_" + System.currentTimeMillis(), result.toString());
                    logInfo("📨 消息捕获: " + methodKey + " -> " + result.toString());
                }
            }
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ⚠️ 捕获方法结果失败: " + e.getMessage());
        }
    }
    
    /**
     * 记录消息信息
     */
    private void logMessage(String type, Object message) {
        try {
            if (message == null) return;
            
            logInfo("📨 " + type + ": " + message.toString());
            
            // 如果是RemoteMessage，尝试获取详细信息
            if (message instanceof RemoteMessage) {
                RemoteMessage remoteMessage = (RemoteMessage) message;
                logInfo("   发送者: " + remoteMessage.getFrom());
                logInfo("   消息ID: " + remoteMessage.getMessageId());
                
                Map<String, String> data = remoteMessage.getData();
                if (data != null && !data.isEmpty()) {
                    logInfo("   数据: " + data.toString());
                }
            }
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ⚠️ 记录消息失败: " + e.getMessage());
        }
    }
    
    // ========== SIM伪装功能 ==========
    
    /**
     * Hook SIM卡相关信息(伪装模式)
     */
    private void hookSIMCardInfo(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            if (!enableSIMSpoofing || fakeSIMConfig == null) {
                XposedBridge.log(TAG + " ⚠️ SIM伪装未启用或配置为空");
                return;
            }
            
            // Hook TelephonyManager方法
            hookTelephonyManager();
            
            // Hook Settings.Secure方法
            hookSettingsSecure();
            
            // Hook SystemProperties方法
            hookSystemPropertiesSpoof();
            
            XposedBridge.log(TAG + " ✅ SIM伪装Hook设置完成，当前配置: " + fakeSIMConfig.toString());
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ❌ SIM伪装Hook失败: " + e.getMessage());
        }
    }
    
    /**
     * 初始化SIM配置
     */
    private void initializeSIMConfigs() {
        try {
            // 初始化预定义配置
            initializePredefinedConfigs();
            
            // 选择默认配置
            selectSIMConfig("random_au");
            
            XposedBridge.log(TAG + " ✅ SIM配置初始化完成");
        } catch (Exception e) {
            XposedBridge.log(TAG + " ❌ SIM配置初始化失败: " + e.getMessage());
        }
    }
    
    /**
     * 初始化预定义配置
     */
    private void initializePredefinedConfigs() {
        // 澳大利亚 Telstra
        PREDEFINED_CONFIGS.put("au_telstra", new SIMConfig(
            "505", "01", 
            generateRandomImsi("505", "01"),
            generateRandomPhone("+61"),
            generateRandomIccid("89610501"),
            "Telstra",
            generateRandomDeviceId(),
            generateRandomAndroidId(),
            "au"
        ));
        
        // 澳大利亚 Optus
        PREDEFINED_CONFIGS.put("au_optus", new SIMConfig(
            "505", "02",
            generateRandomImsi("505", "02"),
            generateRandomPhone("+61"),
            generateRandomIccid("89610502"),
            "Optus",
            generateRandomDeviceId(),
            generateRandomAndroidId(),
            "au"
        ));
        
        // 澳大利亚 Vodafone
        PREDEFINED_CONFIGS.put("au_vodafone", new SIMConfig(
            "505", "03",
            generateRandomImsi("505", "03"),
            generateRandomPhone("+61"),
            generateRandomIccid("89610503"),
            "Vodafone",
            generateRandomDeviceId(),
            generateRandomAndroidId(),
            "au"
        ));
        
        // 美国 Verizon
        PREDEFINED_CONFIGS.put("us_verizon", new SIMConfig(
            "310", "004",
            generateRandomImsi("310", "004"),
            generateRandomPhone("+1"),
            generateRandomIccid("89610310"),
            "Verizon",
            generateRandomDeviceId(),
            generateRandomAndroidId(),
            "us"
        ));
        
        // 英国 EE
        PREDEFINED_CONFIGS.put("uk_ee", new SIMConfig(
            "234", "30",
            generateRandomImsi("234", "30"),
            generateRandomPhone("+44"),
            generateRandomIccid("89610234"),
            "EE",
            generateRandomDeviceId(),
            generateRandomAndroidId(),
            "gb"
        ));
        
        // 中国移动
        PREDEFINED_CONFIGS.put("cn_mobile", new SIMConfig(
            "460", "00",
            generateRandomImsi("460", "00"),
            generateRandomPhone("+86"),
            generateRandomIccid("89860000"),
            "中国移动",
            generateRandomDeviceId(),
            generateRandomAndroidId(),
            "cn"
        ));
        
        // 中国联通
        PREDEFINED_CONFIGS.put("cn_unicom", new SIMConfig(
            "460", "01",
            generateRandomImsi("460", "01"),
            generateRandomPhone("+86"),
            generateRandomIccid("89860001"),
            "中国联通",
            generateRandomDeviceId(),
            generateRandomAndroidId(),
            "cn"
        ));
    }
    
    /**
     * 选择SIM配置
     */
    private void selectSIMConfig(String strategy) {
        switch (strategy) {
            case "random_au":
                // 随机选择澳大利亚配置
                String[] auConfigs = {"au_telstra", "au_optus", "au_vodafone"};
                String selectedConfig = auConfigs[random.nextInt(auConfigs.length)];
                fakeSIMConfig = PREDEFINED_CONFIGS.get(selectedConfig);
                break;
                
            case "random_cn":
                // 随机选择中国配置
                String[] cnConfigs = {"cn_mobile", "cn_unicom"};
                String selectedCnConfig = cnConfigs[random.nextInt(cnConfigs.length)];
                fakeSIMConfig = PREDEFINED_CONFIGS.get(selectedCnConfig);
                break;
                
            case "random_all":
                // 随机选择任意配置
                String[] allConfigs = PREDEFINED_CONFIGS.keySet().toArray(new String[0]);
                String randomConfig = allConfigs[random.nextInt(allConfigs.length)];
                fakeSIMConfig = PREDEFINED_CONFIGS.get(randomConfig);
                break;
                
            default:
                // 使用指定配置
                fakeSIMConfig = PREDEFINED_CONFIGS.get(strategy);
                if (fakeSIMConfig == null) {
                    fakeSIMConfig = PREDEFINED_CONFIGS.get("au_telstra"); // 默认配置
                }
                break;
        }
        
        if (fakeSIMConfig != null) {
            XposedBridge.log(TAG + " 🎭 选择SIM配置: " + fakeSIMConfig.operatorName + 
                           " (" + fakeSIMConfig.getMccMnc() + ")");
            XposedBridge.log(TAG + " 🎭 伪装手机号: " + maskSensitiveInfo(fakeSIMConfig.msisdn));
        }
    }
    
    /**
     * Hook TelephonyManager方法
     */
    private void hookTelephonyManager() {
        try {
            Class<?> tmClass = TelephonyManager.class;
            
            // Hook getSimOperator() - 返回MCC+MNC
            XposedHelpers.findAndHookMethod(tmClass, "getSimOperator", new XC_MethodHook() {
                @Override
                protected void afterHookMethod(MethodHookParam param) throws Throwable {
                    if (fakeSIMConfig != null) {
                        String fakeResult = fakeSIMConfig.getMccMnc();
                        param.setResult(fakeResult);
                        XposedBridge.log(TAG + " 🎭 getSimOperator() -> " + fakeResult);
                    }
                }
            });
            
            // Hook getSubscriberId() - 返回IMSI
            XposedHelpers.findAndHookMethod(tmClass, "getSubscriberId", new XC_MethodHook() {
                @Override
                protected void afterHookMethod(MethodHookParam param) throws Throwable {
                    if (fakeSIMConfig != null) {
                        param.setResult(fakeSIMConfig.imsi);
                        XposedBridge.log(TAG + " 🎭 getSubscriberId() -> " + maskSensitiveInfo(fakeSIMConfig.imsi));
                    }
                }
            });
            
            // Hook getLine1Number() - 返回手机号
            XposedHelpers.findAndHookMethod(tmClass, "getLine1Number", new XC_MethodHook() {
                @Override
                protected void afterHookMethod(MethodHookParam param) throws Throwable {
                    if (fakeSIMConfig != null) {
                        param.setResult(fakeSIMConfig.msisdn);
                        XposedBridge.log(TAG + " 🎭 getLine1Number() -> " + maskSensitiveInfo(fakeSIMConfig.msisdn));
                    }
                }
            });
            
            // Hook getSimSerialNumber() - 返回ICCID
            XposedHelpers.findAndHookMethod(tmClass, "getSimSerialNumber", new XC_MethodHook() {
                @Override
                protected void afterHookMethod(MethodHookParam param) throws Throwable {
                    if (fakeSIMConfig != null) {
                        param.setResult(fakeSIMConfig.iccid);
                        XposedBridge.log(TAG + " 🎭 getSimSerialNumber() -> " + maskSensitiveInfo(fakeSIMConfig.iccid));
                    }
                }
            });
            
            // Hook getDeviceId() - 返回IMEI
            XposedHelpers.findAndHookMethod(tmClass, "getDeviceId", new XC_MethodHook() {
                @Override
                protected void afterHookMethod(MethodHookParam param) throws Throwable {
                    if (fakeSIMConfig != null) {
                        param.setResult(fakeSIMConfig.deviceId);
                        XposedBridge.log(TAG + " 🎭 getDeviceId() -> " + maskSensitiveInfo(fakeSIMConfig.deviceId));
                    }
                }
            });
            
            // Hook getSimState() - 返回SIM状态
            XposedHelpers.findAndHookMethod(tmClass, "getSimState", new XC_MethodHook() {
                @Override
                protected void afterHookMethod(MethodHookParam param) throws Throwable {
                    param.setResult(TelephonyManager.SIM_STATE_READY);
                    XposedBridge.log(TAG + " 🎭 getSimState() -> READY");
                }
            });
            
            // Hook getSimOperatorName() - 返回运营商名称
            XposedHelpers.findAndHookMethod(tmClass, "getSimOperatorName", new XC_MethodHook() {
                @Override
                protected void afterHookMethod(MethodHookParam param) throws Throwable {
                    if (fakeSIMConfig != null) {
                        param.setResult(fakeSIMConfig.operatorName);
                        XposedBridge.log(TAG + " 🎭 getSimOperatorName() -> " + fakeSIMConfig.operatorName);
                    }
                }
            });
            
            // Hook getNetworkOperator() - 返回网络运营商
            XposedHelpers.findAndHookMethod(tmClass, "getNetworkOperator", new XC_MethodHook() {
                @Override
                protected void afterHookMethod(MethodHookParam param) throws Throwable {
                    if (fakeSIMConfig != null) {
                        param.setResult(fakeSIMConfig.getMccMnc());
                        XposedBridge.log(TAG + " 🎭 getNetworkOperator() -> " + fakeSIMConfig.getMccMnc());
                    }
                }
            });
            
            // Hook getSimCountryIso() - 返回国家代码
            XposedHelpers.findAndHookMethod(tmClass, "getSimCountryIso", new XC_MethodHook() {
                @Override
                protected void afterHookMethod(MethodHookParam param) throws Throwable {
                    if (fakeSIMConfig != null) {
                        param.setResult(fakeSIMConfig.countryIso);
                        XposedBridge.log(TAG + " 🎭 getSimCountryIso() -> " + fakeSIMConfig.countryIso);
                    }
                }
            });
            
            XposedBridge.log(TAG + " ✅ TelephonyManager Hook完成");
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ❌ TelephonyManager Hook失败: " + e.getMessage());
        }
    }
    
    /**
     * Hook Settings.Secure方法
     */
    private void hookSettingsSecure() {
        try {
            Class<?> settingsSecureClass = Settings.Secure.class;
            
            // Hook getString() - 主要用于Android ID
            XposedHelpers.findAndHookMethod(settingsSecureClass, "getString", 
                android.content.ContentResolver.class, String.class, new XC_MethodHook() {
                @Override
                protected void afterHookMethod(MethodHookParam param) throws Throwable {
                    String name = (String) param.args[1];
                    
                    if ("android_id".equals(name) && fakeSIMConfig != null) {
                        param.setResult(fakeSIMConfig.androidId);
                        XposedBridge.log(TAG + " 🎭 Settings.Secure.getString(android_id) -> " + 
                                       maskSensitiveInfo(fakeSIMConfig.androidId));
                    }
                }
            });
            
            XposedBridge.log(TAG + " ✅ Settings.Secure Hook完成");
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ❌ Settings.Secure Hook失败: " + e.getMessage());
        }
    }
    
    /**
     * Hook SystemProperties方法
     */
    private void hookSystemPropertiesSpoof() {
        try {
            Class<?> systemPropertiesClass = Class.forName("android.os.SystemProperties");
            
            // Hook get() 方法
            Method getMethod = systemPropertiesClass.getDeclaredMethod("get", String.class);
            XposedBridge.hookMethod(getMethod, new XC_MethodHook() {
                @Override
                protected void afterHookMethod(MethodHookParam param) throws Throwable {
                    String key = (String) param.args[0];
                    
                    if (fakeSIMConfig == null) return;
                    
                    switch (key) {
                        case "gsm.sim.operator.numeric":
                            param.setResult(fakeSIMConfig.getMccMnc());
                            XposedBridge.log(TAG + " 🎭 SystemProperties.get(" + key + ") -> " + 
                                           fakeSIMConfig.getMccMnc());
                            break;
                            
                        case "gsm.sim.operator.alpha":
                            param.setResult(fakeSIMConfig.operatorName);
                            XposedBridge.log(TAG + " 🎭 SystemProperties.get(" + key + ") -> " + 
                                           fakeSIMConfig.operatorName);
                            break;
                            
                        case "gsm.sim.operator.iso-country":
                            param.setResult(fakeSIMConfig.countryIso);
                            XposedBridge.log(TAG + " 🎭 SystemProperties.get(" + key + ") -> " + 
                                           fakeSIMConfig.countryIso);
                            break;
                            
                        case "gsm.sim.state":
                            param.setResult("READY");
                            XposedBridge.log(TAG + " 🎭 SystemProperties.get(" + key + ") -> READY");
                            break;
                    }
                }
            });
            
            // Hook get() 带默认值的方法
            Method getWithDefaultMethod = systemPropertiesClass.getDeclaredMethod("get", String.class, String.class);
            XposedBridge.hookMethod(getWithDefaultMethod, new XC_MethodHook() {
                @Override
                protected void afterHookMethod(MethodHookParam param) throws Throwable {
                    String key = (String) param.args[0];
                    
                    if (fakeSIMConfig == null) return;
                    
                    switch (key) {
                        case "gsm.sim.operator.numeric":
                            param.setResult(fakeSIMConfig.getMccMnc());
                            break;
                        case "gsm.sim.operator.alpha":
                            param.setResult(fakeSIMConfig.operatorName);
                            break;
                        case "gsm.sim.operator.iso-country":
                            param.setResult(fakeSIMConfig.countryIso);
                            break;
                        case "gsm.sim.state":
                            param.setResult("READY");
                            break;
                    }
                }
            });
            
            XposedBridge.log(TAG + " ✅ SystemProperties Hook完成");
            
        } catch (Exception e) {
            XposedBridge.log(TAG + " ❌ SystemProperties Hook失败: " + e.getMessage());
        }
    }
    
    // ========== 工具方法 ==========
    
    /**
     * 生成随机IMSI
     */
    private static String generateRandomImsi(String mcc, String mnc) {
        StringBuilder imsi = new StringBuilder();
        imsi.append(mcc).append(mnc);
        
        // 添加10位随机数字
        for (int i = 0; i < 10; i++) {
            imsi.append(random.nextInt(10));
        }
        
        return imsi.toString();
    }
    
    /**
     * 生成随机手机号
     */
    private static String generateRandomPhone(String countryCode) {
        StringBuilder phone = new StringBuilder();
        phone.append(countryCode);
        
        // 根据国家代码生成相应格式的号码
        if ("+61".equals(countryCode)) {
            // 澳大利亚格式: +61 4xx xxx xxx
            phone.append("4");
            for (int i = 0; i < 8; i++) {
                phone.append(random.nextInt(10));
            }
        } else if ("+1".equals(countryCode)) {
            // 美国格式: +1 xxx xxx xxxx
            phone.append(random.nextInt(9) + 1); // 第一位不能是0
            for (int i = 0; i < 9; i++) {
                phone.append(random.nextInt(10));
            }
        } else if ("+44".equals(countryCode)) {
            // 英国格式: +44 7xxx xxxxxx
            phone.append("7");
            for (int i = 0; i < 9; i++) {
                phone.append(random.nextInt(10));
            }
        } else if ("+86".equals(countryCode)) {
            // 中国格式: +86 1xx xxxx xxxx
            phone.append("1");
            phone.append(random.nextInt(9) + 1); // 第二位不能是0
            for (int i = 0; i < 9; i++) {
                phone.append(random.nextInt(10));
            }
        } else {
            // 默认格式
            for (int i = 0; i < 9; i++) {
                phone.append(random.nextInt(10));
            }
        }
        
        return phone.toString();
    }
    
    /**
     * 生成随机ICCID
     */
    private static String generateRandomIccid(String prefix) {
        StringBuilder iccid = new StringBuilder();
        iccid.append(prefix);
        
        // 添加随机数字到19位
        while (iccid.length() < 19) {
            iccid.append(random.nextInt(10));
        }
        
        return iccid.toString();
    }
    
    /**
     * 生成随机设备ID (IMEI)
     */
    private static String generateRandomDeviceId() {
        StringBuilder deviceId = new StringBuilder();
        
        // IMEI格式: 35-xxxxxx-xxxxxx-x
        deviceId.append("35"); // TAC前缀
        
        for (int i = 0; i < 13; i++) {
            deviceId.append(random.nextInt(10));
        }
        
        return deviceId.toString();
    }
    
    /**
     * 生成随机Android ID
     */
    private static String generateRandomAndroidId() {
        StringBuilder androidId = new StringBuilder();
        String chars = "0123456789abcdef";
        
        for (int i = 0; i < 16; i++) {
            androidId.append(chars.charAt(random.nextInt(chars.length())));
        }
        
        return androidId.toString();
    }
    
    /**
     * 掩码敏感信息
     */
    private String maskSensitiveInfo(String info) {
        if (info == null || info.length() <= 8) return info;
        
        int visibleLength = Math.min(4, info.length() / 4);
        String start = info.substring(0, visibleLength);
        String end = info.substring(info.length() - visibleLength);
        return start + "***" + end;
    }
    
    /**
     * 获取当前时间戳
     */
    private String getCurrentTimestamp() {
        return dateFormat.format(new Date());
    }
    
    /**
     * 记录信息日志
     */
    private void logInfo(String message) {
        if (enableDetailedLogging) {
            XposedBridge.log(TAG + " " + message);
        }
    }
    
    // ========== 公共接口 ==========
    
    /**
     * 获取捕获的Token
     */
    public static Map<String, Object> getCapturedTokens() {
        return new HashMap<>(capturedTokens);
    }
    
    /**
     * 获取捕获的参数
     */
    public static Map<String, Object> getCapturedParams() {
        return new HashMap<>(capturedParams);
    }
    
    /**
     * 获取捕获的消息
     */
    public static Map<String, Object> getCapturedMessages() {
        return new HashMap<>(capturedMessages);
    }
    
    /**
     * 设置SIM伪装功能
     */
    public static void setSIMSpoofing(boolean enabled) {
        enableSIMSpoofing = enabled;
        XposedBridge.log(TAG + " 🎭 SIM伪装: " + (enabled ? "启用" : "禁用"));
    }
    
    /**
     * 设置自定义SIM配置
     */
    public static void setCustomSIMConfig(SIMConfig config) {
        fakeSIMConfig = config;
        if (config != null) {
            XposedBridge.log(TAG + " 🎭 设置自定义SIM配置: " + config.toString());
        }
    }
    
    /**
     * 获取当前SIM配置
     */
    public static SIMConfig getCurrentSIMConfig() {
        return fakeSIMConfig;
    }
    
    /**
     * 设置详细日志
     */
    public static void setDetailedLogging(boolean enabled) {
        enableDetailedLogging = enabled;
        XposedBridge.log(TAG + " 📝 详细日志: " + (enabled ? "启用" : "禁用"));
    }
} 