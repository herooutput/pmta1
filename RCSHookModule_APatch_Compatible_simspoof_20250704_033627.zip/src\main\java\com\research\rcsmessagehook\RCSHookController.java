package com.research.rcsmessagehook;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

import java.util.Map;
import java.util.Iterator;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * RCS Hook控制器类
 * 用于管理Hook模块的配置、数据获取和导出功能
 * 
 * 主要功能：
 * 1. 配置管理（启用/禁用各种Hook功能）
 * 2. 数据获取（Token、参数、消息数据）
 * 3. 数据导出（JSON格式）
 * 4. 日志管理
 * 5. 持久化存储
 * 
 * @author RCS研究团队
 * @version 1.0
 */
public class RCSHookController {
    
    private static final String TAG = "RCSHookController";
    private static final String PREFS_NAME = "rcs_hook_prefs";
    private static final String EXPORT_DIR = "/sdcard/RCS_Hook_Data/";
    
    private Context context;
    private SharedPreferences preferences;
    private static RCSHookController instance;
    
    // 配置选项
    private boolean enableMessageModification = false;
    private boolean enableVerboseLogging = true;
    private boolean enableTokenCapture = true;
    private boolean enableParameterCapture = true;
    private boolean enableMessageCapture = true;
    private String customMessageContent = "";
    
    // 时间格式化器
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault());
    
    /**
     * 私有构造函数，实现单例模式
     */
    private RCSHookController(Context context) {
        this.context = context.getApplicationContext();
        this.preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        loadConfiguration();
        initializeExportDirectory();
    }
    
    /**
     * 获取单例实例
     */
    public static synchronized RCSHookController getInstance(Context context) {
        if (instance == null) {
            instance = new RCSHookController(context);
        }
        return instance;
    }
    
    /**
     * 初始化导出目录
     */
    private void initializeExportDirectory() {
        try {
            File exportDir = new File(EXPORT_DIR);
            if (!exportDir.exists()) {
                boolean created = exportDir.mkdirs();
                if (created) {
                    Log.i(TAG, "📁 导出目录创建成功: " + EXPORT_DIR);
                } else {
                    Log.w(TAG, "⚠️ 导出目录创建失败: " + EXPORT_DIR);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ 初始化导出目录失败", e);
        }
    }
    
    /**
     * 加载配置
     */
    private void loadConfiguration() {
        try {
            enableMessageModification = preferences.getBoolean("enable_message_modification", false);
            enableVerboseLogging = preferences.getBoolean("enable_verbose_logging", true);
            enableTokenCapture = preferences.getBoolean("enable_token_capture", true);
            enableParameterCapture = preferences.getBoolean("enable_parameter_capture", true);
            enableMessageCapture = preferences.getBoolean("enable_message_capture", true);
            customMessageContent = preferences.getString("custom_message_content", "");
            
            Log.i(TAG, "⚙️ 配置加载完成");
        } catch (Exception e) {
            Log.e(TAG, "❌ 配置加载失败", e);
        }
    }
    
    /**
     * 保存配置
     */
    public void saveConfiguration() {
        try {
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("enable_message_modification", enableMessageModification);
            editor.putBoolean("enable_verbose_logging", enableVerboseLogging);
            editor.putBoolean("enable_token_capture", enableTokenCapture);
            editor.putBoolean("enable_parameter_capture", enableParameterCapture);
            editor.putBoolean("enable_message_capture", enableMessageCapture);
            editor.putString("custom_message_content", customMessageContent);
            
            boolean saved = editor.commit();
            if (saved) {
                Log.i(TAG, "💾 配置保存成功");
            } else {
                Log.w(TAG, "⚠️ 配置保存失败");
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ 配置保存异常", e);
        }
    }
    
    // 配置管理方法
    
    /**
     * 设置消息修改功能
     */
    public void setMessageModification(boolean enabled, String customContent) {
        this.enableMessageModification = enabled;
        this.customMessageContent = customContent != null ? customContent : "";
        
        // 同步到Hook模块
        RCSMessageHookModule.setMessageModification(enabled, this.customMessageContent);
        
        Log.i(TAG, "✏️ 消息修改功能: " + (enabled ? "启用" : "禁用"));
        if (enabled && !this.customMessageContent.isEmpty()) {
            Log.i(TAG, "📝 自定义消息内容: " + this.customMessageContent);
        }
    }
    
    /**
     * 设置详细日志
     */
    public void setVerboseLogging(boolean enabled) {
        this.enableVerboseLogging = enabled;
        
        // 同步到Hook模块
        RCSMessageHookModule.setVerboseLogging(enabled);
        
        Log.i(TAG, "📊 详细日志: " + (enabled ? "启用" : "禁用"));
    }
    
    /**
     * 设置Token捕获
     */
    public void setTokenCapture(boolean enabled) {
        this.enableTokenCapture = enabled;
        Log.i(TAG, "🔑 Token捕获: " + (enabled ? "启用" : "禁用"));
    }
    
    /**
     * 设置参数捕获
     */
    public void setParameterCapture(boolean enabled) {
        this.enableParameterCapture = enabled;
        Log.i(TAG, "📋 参数捕获: " + (enabled ? "启用" : "禁用"));
    }
    
    /**
     * 设置消息捕获
     */
    public void setMessageCapture(boolean enabled) {
        this.enableMessageCapture = enabled;
        Log.i(TAG, "📨 消息捕获: " + (enabled ? "启用" : "禁用"));
    }
    
    // 数据获取方法
    
    /**
     * 获取所有捕获的Token
     */
    public Map<String, Object> getCapturedTokens() {
        if (!enableTokenCapture) {
            Log.w(TAG, "⚠️ Token捕获功能未启用");
            return null;
        }
        
        Map<String, Object> tokens = RCSMessageHookModule.getCapturedTokens();
        Log.i(TAG, "🔑 获取Token数据，共 " + tokens.size() + " 条");
        return tokens;
    }
    
    /**
     * 获取所有捕获的参数
     */
    public Map<String, Object> getCapturedParams() {
        if (!enableParameterCapture) {
            Log.w(TAG, "⚠️ 参数捕获功能未启用");
            return null;
        }
        
        Map<String, Object> params = RCSMessageHookModule.getCapturedParams();
        Log.i(TAG, "📋 获取参数数据，共 " + params.size() + " 条");
        return params;
    }
    
    /**
     * 获取所有捕获的消息
     */
    public Map<String, Object> getCapturedMessages() {
        if (!enableMessageCapture) {
            Log.w(TAG, "⚠️ 消息捕获功能未启用");
            return null;
        }
        
        Map<String, Object> messages = RCSMessageHookModule.getCapturedMessages();
        Log.i(TAG, "📨 获取消息数据，共 " + messages.size() + " 条");
        return messages;
    }
    
    /**
     * 获取所有捕获的数据
     */
    public JSONObject getAllCapturedData() {
        try {
            JSONObject allData = new JSONObject();
            
            // 添加元数据
            JSONObject metadata = new JSONObject();
            metadata.put("export_time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
            metadata.put("version", "1.0");
            metadata.put("package_name", "com.google.android.apps.messaging");
            allData.put("metadata", metadata);
            
            // 添加配置信息
            JSONObject config = new JSONObject();
            config.put("enable_message_modification", enableMessageModification);
            config.put("enable_verbose_logging", enableVerboseLogging);
            config.put("enable_token_capture", enableTokenCapture);
            config.put("enable_parameter_capture", enableParameterCapture);
            config.put("enable_message_capture", enableMessageCapture);
            config.put("custom_message_content", customMessageContent);
            allData.put("configuration", config);
            
            // 添加Token数据
            if (enableTokenCapture) {
                Map<String, Object> tokens = getCapturedTokens();
                if (tokens != null) {
                    allData.put("tokens", mapToJSONObject(tokens));
                }
            }
            
            // 添加参数数据
            if (enableParameterCapture) {
                Map<String, Object> params = getCapturedParams();
                if (params != null) {
                    allData.put("parameters", mapToJSONObject(params));
                }
            }
            
            // 添加消息数据
            if (enableMessageCapture) {
                Map<String, Object> messages = getCapturedMessages();
                if (messages != null) {
                    allData.put("messages", mapToJSONObject(messages));
                }
            }
            
            Log.i(TAG, "📦 获取完整数据，JSON大小: " + allData.toString().length() + " 字符");
            return allData;
            
        } catch (JSONException e) {
            Log.e(TAG, "❌ 构建JSON数据失败", e);
            return null;
        }
    }
    
    /**
     * 导出数据到文件
     */
    public String exportDataToFile() {
        try {
            JSONObject allData = getAllCapturedData();
            if (allData == null) {
                Log.e(TAG, "❌ 无数据可导出");
                return null;
            }
            
            String timestamp = dateFormat.format(new Date());
            String fileName = "RCS_Hook_Data_" + timestamp + ".json";
            String filePath = EXPORT_DIR + fileName;
            
            File file = new File(filePath);
            FileWriter writer = new FileWriter(file);
            writer.write(allData.toString(2)); // 格式化JSON，缩进2个空格
            writer.close();
            
            Log.i(TAG, "📁 数据导出成功: " + filePath);
            return filePath;
            
        } catch (IOException e) {
            Log.e(TAG, "❌ 数据导出失败", e);
            return null;
        }
    }
    
    /**
     * 导出数据到指定文件
     */
    public boolean exportDataToFile(String filePath) {
        try {
            JSONObject allData = getAllCapturedData();
            if (allData == null) {
                Log.e(TAG, "❌ 无数据可导出");
                return false;
            }
            
            File file = new File(filePath);
            File parentDir = file.getParentFile();
            if (parentDir != null && !parentDir.exists()) {
                parentDir.mkdirs();
            }
            
            FileWriter writer = new FileWriter(file);
            writer.write(allData.toString(2)); // 格式化JSON，缩进2个空格
            writer.close();
            
            Log.i(TAG, "📁 数据导出成功: " + filePath);
            return true;
            
        } catch (IOException e) {
            Log.e(TAG, "❌ 数据导出失败: " + filePath, e);
            return false;
        }
    }
    
    /**
     * 清空所有捕获的数据
     */
    public void clearAllData() {
        RCSMessageHookModule.clearCapturedData();
        Log.i(TAG, "🗑️ 所有捕获数据已清空");
    }
    
    /**
     * 获取数据统计信息
     */
    public JSONObject getDataStatistics() {
        try {
            JSONObject stats = new JSONObject();
            
            Map<String, Object> tokens = RCSMessageHookModule.getCapturedTokens();
            Map<String, Object> params = RCSMessageHookModule.getCapturedParams();
            Map<String, Object> messages = RCSMessageHookModule.getCapturedMessages();
            
            stats.put("token_count", tokens != null ? tokens.size() : 0);
            stats.put("parameter_count", params != null ? params.size() : 0);
            stats.put("message_count", messages != null ? messages.size() : 0);
            stats.put("total_count", 
                (tokens != null ? tokens.size() : 0) + 
                (params != null ? params.size() : 0) + 
                (messages != null ? messages.size() : 0)
            );
            
            stats.put("last_update", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
            
            return stats;
            
        } catch (JSONException e) {
            Log.e(TAG, "❌ 获取统计信息失败", e);
            return null;
        }
    }
    
    // 辅助方法
    
    /**
     * 将Map转换为JSONObject
     */
    private JSONObject mapToJSONObject(Map<String, Object> map) throws JSONException {
        JSONObject jsonObject = new JSONObject();
        
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            
            if (value == null) {
                jsonObject.put(key, JSONObject.NULL);
            } else if (value instanceof Map) {
                jsonObject.put(key, mapToJSONObject((Map<String, Object>) value));
            } else if (value instanceof String || value instanceof Number || value instanceof Boolean) {
                jsonObject.put(key, value);
            } else {
                // 对于其他类型，转换为字符串
                jsonObject.put(key, value.toString());
            }
        }
        
        return jsonObject;
    }
    
    // Getter方法
    
    public boolean isMessageModificationEnabled() {
        return enableMessageModification;
    }
    
    public boolean isVerboseLoggingEnabled() {
        return enableVerboseLogging;
    }
    
    public boolean isTokenCaptureEnabled() {
        return enableTokenCapture;
    }
    
    public boolean isParameterCaptureEnabled() {
        return enableParameterCapture;
    }
    
    public boolean isMessageCaptureEnabled() {
        return enableMessageCapture;
    }
    
    public String getCustomMessageContent() {
        return customMessageContent;
    }
    
    /**
     * 获取配置信息的JSON格式
     */
    public JSONObject getConfigurationJSON() {
        try {
            JSONObject config = new JSONObject();
            config.put("enable_message_modification", enableMessageModification);
            config.put("enable_verbose_logging", enableVerboseLogging);
            config.put("enable_token_capture", enableTokenCapture);
            config.put("enable_parameter_capture", enableParameterCapture);
            config.put("enable_message_capture", enableMessageCapture);
            config.put("custom_message_content", customMessageContent);
            return config;
        } catch (JSONException e) {
            Log.e(TAG, "❌ 获取配置JSON失败", e);
            return null;
        }
    }
    
    /**
     * 打印当前状态
     */
    public void printStatus() {
        Log.i(TAG, "=== RCS Hook Controller 状态 ===");
        Log.i(TAG, "消息修改: " + (enableMessageModification ? "启用" : "禁用"));
        Log.i(TAG, "详细日志: " + (enableVerboseLogging ? "启用" : "禁用"));
        Log.i(TAG, "Token捕获: " + (enableTokenCapture ? "启用" : "禁用"));
        Log.i(TAG, "参数捕获: " + (enableParameterCapture ? "启用" : "禁用"));
        Log.i(TAG, "消息捕获: " + (enableMessageCapture ? "启用" : "禁用"));
        
        if (enableMessageModification && !customMessageContent.isEmpty()) {
            Log.i(TAG, "自定义消息: " + customMessageContent);
        }
        
        // 打印数据统计
        JSONObject stats = getDataStatistics();
        if (stats != null) {
            try {
                Log.i(TAG, "数据统计: Token(" + stats.getInt("token_count") + 
                          "), 参数(" + stats.getInt("parameter_count") + 
                          "), 消息(" + stats.getInt("message_count") + ")");
            } catch (JSONException e) {
                Log.e(TAG, "❌ 打印统计信息失败", e);
            }
        }
        
        Log.i(TAG, "================================");
    }
} 