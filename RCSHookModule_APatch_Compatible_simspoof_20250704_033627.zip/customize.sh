﻿#!/system/bin/sh
MODDIR=${0%/*}
ui_print "- Installing RCS Hook Module..."
ui_print "- APatch Compatible Version"
ui_print "- SIM Spoofing + RCS Interception"
set_perm_recursive $MODDIR 0 0 0755 0644
ui_print "- Module installed successfully"
ui_print "- Enable in APatch Manager"
